        // STEP 1 

/*
var someMonth;
function theMonth ();
currentMonth;
var summerMonth {};
function myLibrary;
*/

        // STEP 2

/*
5                           // numeral literal
"Hi my name is Jason"       // string literal
true                        // Boolean literal
null                        // literal null value
*/

        //  STEP 3

/*
var name = "Jason";
var thisIsMyFirstExpression = "Hello my name is " + name;
window.console.log(thisIsMyFirstExpression);

var thisIsMySecondExpression = (6 + 11) * 10 / 2;
window.console.log(thisIsMySecondExpression);
*/

        // STEP 4

/*
var srtFirstName, strLastName, strAddress, strCity, strState, intZipCode, intAge, strReferralSource, strContact;
*/

        // STEP 5

/*
var strFirstName;
var strLastName;
var strAddress;
var strCity;
var strState;
var intZipCode;
var intAge;
var strReferralSource;
var strContact;
strFirstName = "jason";
strLastName = "Lapurga";
strAddress = "1551 Lokoya Drive";
strCity = "San Diego";
strState = "Ca";
intZipCode = 92114;
intAge = 26;
strReferralSource = "Brent Darwin";
strContact = "619.621.9991";

var strFirstName = "CJ";
var strLastName = "Jose";
var strAddress = "1234 sumatra lane";
var strCity = "San Diego";
var strState = "Ca";
var intZipCode = 92114;
var intAge = 25;
var strReferralSource = "Jason Lapurga";
var strContact = "619.534.8796";

var strFirstName = "Fermin", strLastName = "Tinamisan", strAddress = "5432 South Sienna", strCity = "San Diego", strState = "Ca", intZipCode = 92114, intAge = 23, strReferralSource = "CJ Jose", strContact = "619.135.7513";
*/

        //STEP 6 

/*
var firstVariable = 8 + "16";
window.console.log(firstVariable);

var secondVariable = true + " hello";
window.console.log(secondVariable);

var thirdVariable = 9 + false;
window.console.log(thirdVariable);
*/

        // STEP 7

/*
var camera = "d3400";
window.console.log("I have a " + camera + " " + company);
var company = "Nikon";
*/

        // STEP 8

/*
var someString = "Who once said, " + '"Only two things are infinite, the universe and human stupidity, and I\'m not sure about the former."' ;
console.log(someString);
*/

        // STEP 9

/*
var firstVariable = 73;
var firstVariable = null;
window.console.log(firstVariable);

var secondVariable;
window.console.log(secondVariable);
*/

        // STEP 10

/*
var name = "Jason";
window.console.log(typeof(name));

var intNumber = 78;
window.console.log(typeof(intNumber));

var bools = true;
window.console.log(typeof(bools));

var obj = [1,2,3];
window.console.log(typeof(obj));

var undef;
window.console.log(typeof(undef));
*/

        // STEP 11

/*
window.alert ("Hello " + "Jason Lapurga" + ", welcome to the JavaScript class!");
*/

        // STEP 12

/*
var name = "Jason";
var name = "name";
window.alert(name);
*/

        // STEP 13

/*
var course = "JavaScript";
window.alert(course);
*/

        // STEP 14

/*
window.alert("Hello Zak Ruvalcaba\nWelcome to the JavaScript class!")
*/

        // STEP 15

/*
var name = "Please enter your name";
window.prompt(name);
*/

        // STEP 16

/*
var course ="Please enter the class you are taking";
window.prompt(course);
*/

        // STEP 17

/*
var x = 10;
var y = 20;
window.console.log(x + y);
*/

        // STEP 18

/*
var x = 20;
window.console.log(x + 20);
*/

        // STEP 19

/*
var x = 20;
window.console.log(x * 5);
*/

        // STEP 20                                 

/*
var x = 20 % 3;
window.console.log(x /= 1);
*/

        // STEP 21

/*
var x = 10;
var y = 15;
window.console.log(x == 10 && y == 15);
*/

        // STEP 22

/*
var a = 20;
var b = 30;
window.console.log(a > 30 || b <= 15);
*/

        // STEP 23                              

/*
var widget = new Object();
window.console.log(typeof(widget));
*/

        // STEP 24                              

/*
var widget = new Object();
window.console.log(widget instanceof Object);
*/

        // STEP 25

/*
var widget = new Object();
window.console.log(widget instanceof Number);
*/

